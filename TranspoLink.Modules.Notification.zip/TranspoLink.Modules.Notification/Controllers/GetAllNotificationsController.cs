﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using TranspoLink.Modules.Notification.Application.DTOs;
using TranspoLink.Modules.Notification.Application.Interfaces;
using TranspoLink.SharedKernel.Enums;

namespace TranspoLink.Modules.Notification.Application.Controllers
{
    /// <summary>
    /// PURPOSE: Admin sees all notifications across every category.
    /// Only the Admin role can call this — no user filter applied.
    /// GET: api/notifications/all
    /// </summary>
    [ApiController]
    [Route("api/notifications")]
    [Authorize(Roles = nameof(UserRole.Admin))]
    public class GetAllNotificationsController : ControllerBase
    {
        private readonly INotificationService _service;

        public GetAllNotificationsController(INotificationService service)
            => _service = service;

        [HttpGet("all")]
        public async Task<ActionResult<List<NotificationReadDto>>> GetAllNotifications(
            [FromQuery] NotificationQueryParameters qp,
            CancellationToken ct)
        {
            var notifications = await _service.GetAsync(qp, ct);
            return Ok(notifications);
        }
    }
}
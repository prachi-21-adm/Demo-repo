﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using TranspoLink.Modules.Notification.Application.Interfaces;
using TranspoLink.SharedKernel.Enums;

namespace TranspoLink.Modules.Notification.Application.Controllers
{
    /// <summary>
    /// PURPOSE: Mark a notification as read.
    /// All roles can mark their own notifications as read.
    /// This is a partial state change — uses PATCH, not PUT.
    /// PATCH: api/notifications/{notificationId}/mark-as-read
    /// </summary>
    [ApiController]
    [Route("api/notifications")]
    [Authorize]
    public class MarkNotificationAsReadController : ControllerBase
    {
        private readonly INotificationService _service;

        public MarkNotificationAsReadController(INotificationService service)
            => _service = service;

        [HttpPatch("{notificationId:guid}/mark-as-read")]
        public async Task<IActionResult> MarkNotificationAsRead(
            Guid notificationId,
            CancellationToken ct)
        {
            var success = await _service.MarkAsReadAsync(notificationId, ct);
            return success ? NoContent() : NotFound();
        }
    }
}
﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using TranspoLink.Modules.Notification.Application.Interfaces;
using TranspoLink.SharedKernel.Enums;

namespace TranspoLink.Modules.Notification.Application.Controllers
{
    /// <summary>
    /// PURPOSE: Permanently delete a notification.
    /// Only Admin can delete notifications — citizens and officers cannot.
    /// DELETE: api/notifications/{notificationId}/remove
    /// </summary>
    [ApiController]
    [Route("api/notifications")]
    [Authorize(Roles = nameof(UserRole.Admin))]
    public class DeleteNotificationController : ControllerBase
    {
        private readonly INotificationService _service;

        public DeleteNotificationController(INotificationService service)
            => _service = service;

        [HttpDelete("{notificationId:guid}/remove")]
        public async Task<IActionResult> DeleteNotification(
            Guid notificationId,
            CancellationToken ct)
        {
            var success = await _service.DeleteAsync(notificationId, ct);
            return success ? NoContent() : NotFound();
        }
    }
}
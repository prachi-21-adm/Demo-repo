﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using TranspoLink.Modules.Notification.Application.DTOs;
using TranspoLink.Modules.Notification.Application.Interfaces;
using TranspoLink.SharedKernel.Enums;

namespace TranspoLink.Modules.Notification.Application.Controllers
{
    /// <summary>
    /// PURPOSE: Citizens fetch only their own notifications.
    /// UserId is always read from the JWT token — never from the request.
    /// GET: api/notifications/my
    /// </summary>
    [ApiController]
    [Route("api/notifications")]
    [Authorize(Roles = nameof(UserRole.Citizen))]
    public class GetMyNotificationsController : ControllerBase
    {
        private readonly INotificationService _service;

        public GetMyNotificationsController(INotificationService service)
            => _service = service;

        [HttpGet("my")]
        public async Task<ActionResult<List<NotificationReadDto>>> GetMyNotifications(
            CancellationToken ct)
        {
            var userId = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

            var qp = new NotificationQueryParameters { UserId = userId };

            var notifications = await _service.GetAsync(qp, ct);
            return Ok(notifications);
        }
    }
}
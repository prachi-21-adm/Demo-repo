﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using TranspoLink.Modules.Notification.Application.DTOs;
using TranspoLink.Modules.Notification.Application.Interfaces;
using TranspoLink.SharedKernel.Enums;

namespace TranspoLink.Modules.Notification.Application.Controllers
{
    /// <summary>
    /// PURPOSE: Manually create a notification via the API.
    /// This is for Admin use only — most notifications are created
    /// automatically by event handlers (IncidentCreatedHandler, etc.)
    /// POST: api/notifications/create
    /// </summary>
    [ApiController]
    [Route("api/notifications")]
    [Authorize(Roles = nameof(UserRole.Admin))]
    public class CreateNotificationController : ControllerBase
    {
        private readonly INotificationService _service;

        public CreateNotificationController(INotificationService service)
            => _service = service;

        [HttpPost("create")]
        public async Task<ActionResult<NotificationReadDto>> CreateNotification(
            [FromBody] NotificationCreateDto dto,
            CancellationToken ct)
        {
            var created = await _service.CreateAsync(dto, ct);
            return CreatedAtAction(
                nameof(GetNotificationByIdController.GetNotificationById),
                "GetNotificationById",
                new { notificationId = created.NotificationID },
                created);
        }
    }
}
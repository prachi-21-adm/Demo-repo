//using Azure;
//using Microsoft.AspNetCore.Authorization;
//using Microsoft.AspNetCore.Mvc;
//using System.Runtime.InteropServices;
//using TranspoLink.Modules.Notification.Application.DTOs;
//using TranspoLink.Modules.Notification.Application.Interfaces;

//namespace TranspoLink.Modules.Notification.Application.Controllers
//{
//    [ApiController]
//    [Route("api/[controller]")]
//    [Authorize] // keep or remove based on your JWT setup
//    public class NotificationsController : ControllerBase
//    {
//        private readonly INotificationService _service;

//        public NotificationsController(INotificationService service) => _service = service;


//        // GET: api/notifications/5
//        [HttpGet("{id:Guid}/Getid")]
//        public async Task<ActionResult<NotificationReadDto>> GetById(Guid id, CancellationToken ct)
//        {
//            var item = await _service.GetByIdAsync(id, ct);
//            return item is null ? NotFound() : Ok(item);
//        }

//        // POST: api/notifications
//        [HttpPost]
//        public async Task<ActionResult<NotificationReadDto>> Create([FromBody] NotificationCreateDto dto, CancellationToken ct)
//        {
//            var created = await _service.CreateAsync(dto, ct);
//            return CreatedAtAction(nameof(GetById), new { id = created.NotificationID }, created);
//        }

//        // PUT: api/notifications/5
//        [HttpPut("{id:Guid}/update")]
//        public async Task<IActionResult> Update(Guid id, [FromBody] NotificationUpdateDto dto, CancellationToken ct)
//        {
//            var ok = await _service.UpdateAsync(id, dto, ct);
//            return ok ? NoContent() : NotFound();
//        }

//        // PATCH: api/notifications/5/read
//        [HttpPatch("{id:Guid}/read")]
//        public async Task<IActionResult> MarkAsRead(Guid id, CancellationToken ct)
//        {
//            var ok = await _service.MarkAsReadAsync(id, ct);
//            return ok ? NoContent() : NotFound();
//        }

//        // DELETE: api/notifications/5
//        [HttpDelete("{id:Guid}/delete")]
//        public async Task<IActionResult> Delete(Guid id, CancellationToken ct)
//        {
//            var ok = await _service.DeleteAsync(id, ct);
//            return ok ? NoContent() : NotFound();
//        }
//    }
//}
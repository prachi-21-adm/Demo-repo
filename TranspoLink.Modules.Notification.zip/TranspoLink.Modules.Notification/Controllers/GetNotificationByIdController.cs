﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using TranspoLink.Modules.Notification.Application.DTOs;
using TranspoLink.Modules.Notification.Application.Interfaces;
using TranspoLink.SharedKernel.Enums;

namespace TranspoLink.Modules.Notification.Application.Controllers
{
    /// <summary>
    /// PURPOSE: Fetch a single notification by its ID.
    /// Citizens can only fetch their own notification.
    /// Officers, Operators, Compliance, Admin can fetch any.
    /// GET: api/notifications/{notificationId}
    /// </summary>
    [ApiController]
    [Route("api/notifications")]
    [Authorize]
    public class GetNotificationByIdController : ControllerBase
    {
        private readonly INotificationService _service;

        public GetNotificationByIdController(INotificationService service)
            => _service = service;

        [HttpGet("{notificationId:guid}")]
        public async Task<ActionResult<NotificationReadDto>> GetNotificationById(
            Guid notificationId,
            CancellationToken ct)
        {
            var notification = await _service.GetByIdAsync(notificationId, ct);
            if (notification is null) return NotFound();

            // Citizens can only view their own notifications
            var role = User.FindFirstValue(ClaimTypes.Role);
            if (role == nameof(UserRole.Citizen))
            {
                var userId = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
                if (notification.UserID != userId) return Forbid();
            }

            return Ok(notification);
        }
    }
}
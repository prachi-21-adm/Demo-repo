﻿using FluentValidation;
using TranspoLink.Modules.Notification.Application.DTOs;

namespace TranspoLink.Modules.Notification.Application.Validators
{
    public class NotificationUpdateDtoValidator : AbstractValidator<NotificationUpdateDto>
    {
        public NotificationUpdateDtoValidator()
        {
            RuleFor(x => x.Message)
                .NotEmpty()
                .MaximumLength(500);

            RuleFor(x => x.Category)
                .NotEmpty()
                .MaximumLength(100);

            RuleFor(x => x.Status)
                .IsInEnum();
        }
    }
}
using FluentValidation;
using TranspoLink.Modules.Notification.Application.DTOs;

namespace TranspoLink.Modules.Notification.Application.Validators
{
    public class NotificationCreateDtoValidator : AbstractValidator<NotificationCreateDto>
    {
        public NotificationCreateDtoValidator()
        {
            RuleFor(x => x.UserID)
                .NotEmpty().WithMessage("UserID is required.");

            RuleFor(x => x.EntityID)
                .NotEmpty().WithMessage("EntityID is required.");

            RuleFor(x => x.Message)
                .NotEmpty()
                .MaximumLength(500);

            RuleFor(x => x.Category)
                .NotEmpty()
                .MaximumLength(100);

            RuleFor(x => x.Status)
                .IsInEnum();
        }
    }
}
using AutoMapper;
using AutoMapper.QueryableExtensions;
using Microsoft.EntityFrameworkCore;

using TranspoLink.Modules.Notification.Application.DTOs;
using TranspoLink.Modules.Notification.Application.Interfaces;
//using TranspoLink.Modules.Notification.Domain.Entities;
using TranspoLink.Modules.Notification.Infrastructure.Repositories;
using TranspoLink.SharedKernel.Enums;
using TranspoLink.Modules.Notification.Domain.Entities;

namespace TranspoLink.Modules.Notification.Application.Services
{
    public class NotificationService : INotificationService
    {
        private readonly INotificationRepository _repo;
        private readonly IMapper _mapper;

        public NotificationService(INotificationRepository repo, IMapper mapper)
        {
            _repo = repo;
            _mapper = mapper;
        }

        // ================================
        // GET WITH FILTER (NO PAGINATION)
        // ================================
        public async Task<List<NotificationReadDto>> GetAsync(
            NotificationQueryParameters qp,
            CancellationToken ct = default)
        {
            var query = _repo.Query();

            if (qp.UserId.HasValue)
                query = query.Where(n => n.UserID == qp.UserId.Value);

            if (!string.IsNullOrWhiteSpace(qp.Category))
                query = query.Where(n => n.Category == qp.Category);

            if (qp.Status.HasValue)
                query = query.Where(n => n.Status == qp.Status.Value);

            if (!string.IsNullOrWhiteSpace(qp.Search))
                query = query.Where(n => n.Message.Contains(qp.Search));

            return await query
                .OrderByDescending(n => n.CreatedDate)
                .ProjectTo<NotificationReadDto>(_mapper.ConfigurationProvider)
                .ToListAsync(ct);
        }

        // ================================
        // GET BY ID
        // ================================
        public async Task<NotificationReadDto?> GetByIdAsync(Guid id, CancellationToken ct = default)
        {
            var entity = await _repo.GetByIdAsync(id, ct);
            return entity is null ? null : _mapper.Map<NotificationReadDto>(entity);
        }

        // ================================
        // CREATE (Normal API create)
        // ================================
        public async Task<NotificationReadDto> CreateAsync(
            NotificationCreateDto dto,
            CancellationToken ct = default)
        {
            var entity = _mapper.Map<NotificationAlert>(dto);
            entity.NotificationID = Guid.NewGuid();
            entity.CreatedDate = DateTime.UtcNow;

            await _repo.AddAsync(entity, ct);
            await _repo.SaveChangesAsync(ct);

            return _mapper.Map<NotificationReadDto>(entity);
        }

        // ================================
        // UPDATE
        // ================================
        public async Task<bool> UpdateAsync(Guid id, NotificationUpdateDto dto, CancellationToken ct = default)
        {
            var entity = await _repo.GetByIdAsync(id, ct);
            if (entity is null) return false;

            _mapper.Map(dto, entity);

            await _repo.UpdateAsync(entity, ct);
            await _repo.SaveChangesAsync(ct);

            return true;
        }

        // ================================
        // DELETE
        public async Task<bool> DeleteAsync(Guid id, CancellationToken ct = default)
        {
            var entity = await _repo.GetByIdAsync(id, ct);
            if (entity is null) return false;

            await _repo.DeleteAsync(entity, ct);
            await _repo.SaveChangesAsync(ct);

            return true;
        }

        // ....MARK AS READ
        public async Task<bool> MarkAsReadAsync(Guid id, CancellationToken ct = default)
        {
            var entity = await _repo.GetByIdAsync(id, ct);
            if (entity is null) return false;

            entity.Status = StatusType.Read;

            await _repo.UpdateAsync(entity, ct);
            await _repo.SaveChangesAsync(ct);

            return true;
        }

        // EVENT-BASED CREATION (System Event)
        public async Task<NotificationAlert> CreateNotificationAsync(NotificationRequestDto request, CancellationToken ct = default)
        {
            var entity = new NotificationAlert
            {
                NotificationID = Guid.NewGuid(),
                UserID = request.CreatedBy,
                EntityID = request.EntityId,
                Category = request.Category,
                Message = request.Message,
                Status = StatusType.Unread,
                CreatedDate = DateTime.UtcNow
            };

            await _repo.AddAsync(entity,ct);
            await _repo.SaveChangesAsync(ct);

            return entity;
        }
    }
}



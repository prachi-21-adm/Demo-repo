using TranspoLink.SharedKernel.Enums;

namespace TranspoLink.Modules.Notification.Application.DTOs
{
    public class NotificationQueryParameters
    {
        public Guid? UserId { get; set; }

        // Entity uses string for Category
        public string? Category { get; set; }

        // Entity uses StatusType enum
        public StatusType? Status { get; set; }

        public string? Search { get; set; }

    }
}
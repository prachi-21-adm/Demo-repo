﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Text;
using TranspoLink.SharedKernel.Enums;
using static TranspoLink.SharedKernel.Constants.AppConstants;

namespace TranspoLink.Modules.Notification.Application.DTOs
{
    public class NotificationCreateDto 
    {
        public Guid UserID { get; set; }
        public Guid EntityID { get; set; }
        public string Message { get; set; } = string.Empty;
        public string? Category { get; set; }
        public StatusType? Status { get; set; }
    }
}

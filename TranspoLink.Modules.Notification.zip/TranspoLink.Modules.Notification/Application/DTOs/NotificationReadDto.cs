﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TranspoLink.Modules.Notification.Application.DTOs
{
    public class NotificationReadDto
    {
        public int NotificationID { get; set; }
        public Guid UserID { get; set; }
        public int EntityID { get; set; }
        public string Message { get; set; } = string.Empty;
        public string Category { get; set; } = string.Empty;
        public string Status { get; set; } = string.Empty;
        public DateTime CreatedDate { get; set; }

    }
}

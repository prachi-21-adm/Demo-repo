﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TranspoLink.Modules.Notification.Application.DTOs
{
    public class NotificationRequestDto
    {

        public string Category { get; set; } = string.Empty;
        public string Message { get; set; } = string.Empty;
        public Guid EntityId { get; set; }
        public Guid CreatedBy { get; set; }

    }
}

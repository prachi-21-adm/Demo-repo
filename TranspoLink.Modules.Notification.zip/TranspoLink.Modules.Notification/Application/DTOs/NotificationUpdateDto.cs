﻿using TranspoLink.SharedKernel.Enums;

namespace TranspoLink.Modules.Notification.Application.DTOs
{
    public class NotificationUpdateDto
    {
        public string Message { get; set; } = string.Empty;

        // Category in entity is string
        public string Category { get; set; } = string.Empty;

        // Entity uses StatusType enum
        public StatusType Status { get; set; }
    }
}
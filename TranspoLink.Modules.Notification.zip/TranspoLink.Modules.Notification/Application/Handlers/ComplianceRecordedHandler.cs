﻿using TranspoLink.SharedKernel.EventBus;
using TranspoLink.Modules.Notification.Application.DTOs;
using TranspoLink.Modules.Notification.Application.Interfaces;

public class ComplianceRecordedHandler : IEventHandler<ComplianceRecordedEvent>
{
    private readonly INotificationService _service;
    public ComplianceRecordedHandler(INotificationService service) => _service = service;

    public async Task HandleAsync(ComplianceRecordedEvent evt, CancellationToken ct = default)
    {
        await _service.CreateNotificationAsync(new NotificationRequestDto
        {
            CreatedBy = evt.OfficerId,
            EntityId = evt.RecordId,
            Category = "Compliance",
            Message = $"New compliance record added: {evt.Description}"
        },ct);
    }
}
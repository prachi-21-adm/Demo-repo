﻿using TranspoLink.Modules.Notification.Application.DTOs;
using TranspoLink.Modules.Notification.Application.Interfaces;
using TranspoLink.SharedKernel.EventBus;

public class ComplianceDueHandler : IEventHandler<ComplianceDueEvent>
{
    private readonly INotificationService _service;
    public ComplianceDueHandler(INotificationService service) => _service = service;

    public async Task HandleAsync(ComplianceDueEvent evt, CancellationToken ct = default)
    {
        await _service.CreateNotificationAsync(new NotificationRequestDto
        {
            CreatedBy = Guid.Empty,          // system-generated, no specific user
            EntityId = evt.RecordId,
            Category = "Compliance",
            Message = $"Compliance deadline approaching: {evt.Deadline:dd MMM yyyy}"
        },ct);
    }
}


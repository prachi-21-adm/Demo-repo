﻿using TranspoLink.Modules.Notification.Application.DTOs;
using TranspoLink.Modules.Notification.Application.Interfaces;
using TranspoLink.Modules.Notification.MockEvents;
using TranspoLink.SharedKernel.EventBus;

public class IncidentCreatedHandler : IEventHandler<IncidentCreatedEvent>
{
    private readonly INotificationService _service;
    public IncidentCreatedHandler(INotificationService service) => _service = service;

    public async Task HandleAsync(IncidentCreatedEvent evt, CancellationToken ct = default)
    {
        await _service.CreateNotificationAsync(new NotificationRequestDto
        {
            CreatedBy = evt.ReportedBy,
            EntityId = evt.IncidentId,
            Category = "Incident",
            Message = $"New {evt.Type} incident reported at {evt.Location}."
        },ct);
    }
}

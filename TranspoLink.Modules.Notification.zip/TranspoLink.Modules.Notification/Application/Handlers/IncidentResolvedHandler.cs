﻿using TranspoLink.SharedKernel.EventBus;
using TranspoLink.Modules.Notification.Application.DTOs;
using TranspoLink.Modules.Notification.Application.Interfaces;
using TranspoLink.Modules.Notification.MockEvents;

public class IncidentResolvedHandler : IEventHandler<IncidentResolvedEvent>
{
    private readonly INotificationService _service;
    public IncidentResolvedHandler(INotificationService service) => _service = service;

    public async Task HandleAsync(IncidentResolvedEvent evt, CancellationToken ct = default)
    {
        await _service.CreateNotificationAsync(new NotificationRequestDto
        {
            CreatedBy = evt.ResolvedBy,
            EntityId = evt.IncidentId,
            Category = "Incident",
            Message = $"Incident {evt.IncidentId} has been resolved."
        },ct);
    }
}

﻿using TranspoLink.Modules.Notification.Application.DTOs;
using TranspoLink.Modules.Notification.Application.Interfaces;
using TranspoLink.SharedKernel.EventBus;

public class RouteDelayedHandler : IEventHandler<RouteDelayedEvent>
{
    private readonly INotificationService _service;
    public RouteDelayedHandler(INotificationService service) => _service = service;

    public async Task HandleAsync(RouteDelayedEvent evt, CancellationToken ct = default)
    {
        await _service.CreateNotificationAsync(new NotificationRequestDto
        {
            CreatedBy = Guid.Empty,          // system-generated
            EntityId = evt.RouteId,
            Category = "Transport",
            Message = $"Route {evt.RouteId} is delayed by {evt.DelayMinutes} minutes."
        },ct);
    }
}

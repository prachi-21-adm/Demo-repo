﻿using TranspoLink.SharedKernel.EventBus;
using TranspoLink.Modules.Notification.Application.DTOs;
using TranspoLink.Modules.Notification.Application.Interfaces;

public class ScheduleChangedHandler : IEventHandler<ScheduleChangedEvent>
{
    private readonly INotificationService _service;
    public ScheduleChangedHandler(INotificationService service) => _service = service;

    public async Task HandleAsync(ScheduleChangedEvent evt, CancellationToken ct = default)
    {
        await _service.CreateNotificationAsync(new NotificationRequestDto
        {
            CreatedBy = Guid.Empty,          // system-generated
            EntityId = evt.RouteId,
            Category = "Transport",
            Message = $"Route {evt.RouteId} schedule updated: {evt.NewSchedule}"
        },ct);
    }
}

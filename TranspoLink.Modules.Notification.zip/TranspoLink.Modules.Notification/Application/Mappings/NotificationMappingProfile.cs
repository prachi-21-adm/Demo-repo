using AutoMapper;
using TranspoLink.Modules.Notification.Application.DTOs;
using TranspoLink.Modules.Notification.Domain.Entities;
using TranspoLink.SharedKernel.Enums;

namespace TranspoLink.Modules.Notification.Application.Mappings
{
    public class NotificationMappingProfile : Profile
    {
        public NotificationMappingProfile()
        {
            // CREATE
            CreateMap<NotificationCreateDto, NotificationAlert>()
                .ForMember(d => d.NotificationID, opt => opt.MapFrom(_ => Guid.NewGuid()))
                .ForMember(d => d.Status, opt => opt.MapFrom(s => s.Status))
                .ForMember(d => d.Category, opt => opt.MapFrom(s => s.Category));

            // UPDATE
            CreateMap<NotificationUpdateDto, NotificationAlert>();

            // READ DTO
            CreateMap<NotificationAlert, NotificationReadDto>();
        }
    }
}

using TranspoLink.Modules.Notification.Application.DTOs;
using TranspoLink.Modules.Notification;
using TranspoLink.Modules.Notification.Domain.Entities;

namespace TranspoLink.Modules.Notification.Application.Interfaces
{
    public interface INotificationService
    {
        // READ
        Task<List<NotificationReadDto>> GetAsync(NotificationQueryParameters qp, CancellationToken ct = default);
        Task<NotificationReadDto?> GetByIdAsync(Guid id, CancellationToken ct = default);

        // WRITE
        Task<NotificationReadDto> CreateAsync(NotificationCreateDto dto, CancellationToken ct = default);
        Task<bool> UpdateAsync(Guid id, NotificationUpdateDto dto, CancellationToken ct = default);
        Task<bool> DeleteAsync(Guid id, CancellationToken ct = default);
        Task<bool> MarkAsReadAsync(Guid id, CancellationToken ct = default);

        // EVENT-BASED (called by handlers, not the controller)
        Task<NotificationAlert> CreateNotificationAsync(NotificationRequestDto request, CancellationToken ct);
    }
}
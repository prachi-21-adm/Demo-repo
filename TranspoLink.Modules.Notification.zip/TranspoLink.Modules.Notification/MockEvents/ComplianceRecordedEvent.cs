﻿using TranspoLink.SharedKernel.EventBus;

//namespace TranspoLink.Modules.Compliance.Events;

/// Published when a compliance officer records a new compliance entry.
public class ComplianceRecordedEvent : BaseEvent
{
    public Guid RecordId { get; init; }
    public Guid OfficerId { get; init; }
    public string Description { get; init; } = string.Empty;
    public string Type { get; init; } = string.Empty;  // Incident/Transport
}

/// Published by a background job (or scheduler) when a deadline is approaching.

﻿using TranspoLink.SharedKernel.EventBus;

//namespace TranspoLink.Modules.Transport.Events;

/// Published when a route is running behind schedule.
public class RouteDelayedEvent : BaseEvent
{
    public Guid RouteId { get; init; }
    public int DelayMinutes { get; init; }
}

/// Published when an operator changes a route's timetable.


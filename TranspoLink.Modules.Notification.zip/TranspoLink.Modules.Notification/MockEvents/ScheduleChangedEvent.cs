﻿using TranspoLink.SharedKernel.EventBus;

public class ScheduleChangedEvent : BaseEvent
{
    public Guid RouteId { get; init; }
    public string NewSchedule { get; init; } = string.Empty;  // e.g. "06:00 – 22:00, every 15 min"
}
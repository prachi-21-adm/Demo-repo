﻿using TranspoLink.SharedKernel.EventBus;

//namespace TranspoLink.Modules.Compliance.Events;

/// Published when a compliance officer records a new compliance entry.


public class ComplianceDueEvent : BaseEvent
{
    public Guid RecordId { get; init; }
    public DateTime Deadline { get; init; }
}

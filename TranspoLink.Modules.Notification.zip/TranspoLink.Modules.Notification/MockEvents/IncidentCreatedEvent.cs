﻿using TranspoLink.SharedKernel.EventBus;

namespace TranspoLink.Modules.Notification.MockEvents;

/// Published when a citizen / officer creates a new incident.
public class IncidentCreatedEvent : BaseEvent
{
    public Guid IncidentId { get; init; }
    public Guid ReportedBy { get; init; }   // UserId of the reporter
    public string Location { get; init; } = string.Empty;
    public string Type { get; init; } = string.Empty;  // Accident/Breakdown/Roadblock
}

/// Published when an officer marks an incident as resolved.

﻿using TranspoLink.SharedKernel.EventBus;

namespace TranspoLink.Modules.Notification.MockEvents;



public class IncidentResolvedEvent : BaseEvent
{
    public Guid IncidentId { get; init; }
    public Guid ResolvedBy { get; init; }   // OfficerId
    public string Notes { get; init; } = string.Empty;
}

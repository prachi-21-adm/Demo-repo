// Restrict delete on UserId FK, Category max-length
namespace TranspoLink;

// TODO: Implement

﻿using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;
using Microsoft.EntityFrameworkCore;
using TranspoLink.Modules.Notification.Infrastructure.EF;

namespace TranspoLink.Modules.Compliance.Infrastructure.EF.Repositories.data;

public class ComplianceDbContextFactory : IDesignTimeDbContextFactory<NotificationDbContext>
{

  public NotificationDbContext CreateDbContext(string[] args)

  {

        var config = new ConfigurationBuilder()

    .SetBasePath(Path.Combine(Directory.GetCurrentDirectory(), "../TranspoLink.Api"))

    .AddJsonFile("appsettings.json")

    .Build();


        var optionsBuilder = new DbContextOptionsBuilder<NotificationDbContext>();


        optionsBuilder.UseSqlServer(config.GetConnectionString("Default"));


        return new NotificationDbContext(optionsBuilder.Options);

	}

}
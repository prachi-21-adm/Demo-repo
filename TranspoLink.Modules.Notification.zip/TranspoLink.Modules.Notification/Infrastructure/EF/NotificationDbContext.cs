using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using TranspoLink.Modules.Notification.Domain.Entities;

namespace TranspoLink.Modules.Notification.Infrastructure.EF
{
    public class NotificationDbContext : DbContext
    {
        public NotificationDbContext(DbContextOptions<NotificationDbContext> options)
            : base(options) { }

        public DbSet<NotificationAlert> Notifications { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            modelBuilder.ApplyConfigurationsFromAssembly(typeof(NotificationDbContext).Assembly);
            base.OnModelCreating(modelBuilder);
        }
    }
    public class ComplianceDbContextFactory : IDesignTimeDbContextFactory<NotificationDbContext>
    {
        public NotificationDbContext CreateDbContext(string[] args)
        {
            var optionsBuilder = new DbContextOptionsBuilder<NotificationDbContext>();

            // Use the same connection string name as your appsettings.json
            // For local development, you can hardcode it here just for the migration tool
            optionsBuilder.UseSqlServer("Server=LTIN718810;Database=TranspoLink;Trusted_Connection=True;TrustServerCertificate=True;");
            //
            return new NotificationDbContext(optionsBuilder.Options);
        }
    }
}


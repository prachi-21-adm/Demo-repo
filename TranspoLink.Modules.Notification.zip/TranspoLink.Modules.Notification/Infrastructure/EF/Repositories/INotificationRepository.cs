﻿using System.Linq.Expressions;
using TranspoLink.Modules.Notification.Domain.Entities;

////using TranspoLink.Modules.Notification.Domain.Entities;
//using TranspoLink.Modules.Notification.Domain.Entities;

namespace TranspoLink.Modules.Notification.Infrastructure.Repositories
{
    public interface INotificationRepository
    {
        Task<NotificationAlert?> GetByIdAsync(Guid id, CancellationToken ct = default);
        IQueryable<NotificationAlert> Query();
        Task AddAsync(NotificationAlert entity, CancellationToken ct = default);
        Task UpdateAsync(NotificationAlert entity, CancellationToken ct = default);
        Task DeleteAsync(NotificationAlert entity, CancellationToken ct = default);
        Task<int> SaveChangesAsync(CancellationToken ct = default);
    }
}
using Microsoft.EntityFrameworkCore;
using TranspoLink.Modules.Notification.Domain.Entities;
using TranspoLink.Modules.Notification.Infrastructure.EF;

namespace TranspoLink.Modules.Notification.Infrastructure.Repositories
{
    public class NotificationRepository : INotificationRepository
    {
        private readonly NotificationDbContext _db;

        public NotificationRepository(NotificationDbContext db) => _db = db;

        public IQueryable<NotificationAlert> Query() => _db.Notifications.AsQueryable();

        public Task<NotificationAlert?> GetByIdAsync(Guid id, CancellationToken ct = default)
            => _db.Notifications.FirstOrDefaultAsync(n => n.NotificationID == id, ct);

        public async Task AddAsync(NotificationAlert entity, CancellationToken ct = default)
            => await _db.Notifications.AddAsync(entity, ct);

        public Task UpdateAsync(NotificationAlert entity, CancellationToken ct = default)
        {
            _db.Notifications.Update(entity);
            return Task.CompletedTask;
        }

        public Task DeleteAsync(NotificationAlert entity, CancellationToken ct = default)
        {
            _db.Notifications.Remove(entity);
            return Task.CompletedTask;
        }

        public Task<int> SaveChangesAsync(CancellationToken ct = default)
            => _db.SaveChangesAsync(ct);
    }
}
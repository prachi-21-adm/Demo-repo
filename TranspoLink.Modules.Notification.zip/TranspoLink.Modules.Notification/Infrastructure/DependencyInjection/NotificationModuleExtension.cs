﻿using Microsoft.AspNetCore.Builder;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
//using TranspoLink.Modules.Notification.Application.Handlers;
using TranspoLink.Modules.Notification.Application.Interfaces;
using TranspoLink.Modules.Notification.Application.Services;
using TranspoLink.Modules.Notification.Infrastructure.EF;
using TranspoLink.Modules.Notification.Infrastructure.Repositories;
using TranspoLink.Modules.Notification.MockEvents;
using TranspoLink.SharedKernel.EventBus;

namespace TranspoLink.Modules.Notification.Infrastructure.DependencyInjection
{
    public static class NotificationModuleExtension
    {
        // called BEFORE app.Build()
        public static IServiceCollection AddNotificationModule(
            this IServiceCollection services,
            IConfiguration configuration)
        {
            // DbContext
            services.AddDbContext<NotificationDbContext>(options =>
                options.UseSqlServer(configuration.GetConnectionString("DefaultConnection")));



            //services.AddAutoMapper(typeof(NotificationModuleExtension).Assembly);
            services.AddAutoMapper(cfg => {
                cfg.AddMaps(typeof(NotificationModuleExtension).Assembly);

            });



            // Repository + Service
            services.AddScoped<INotificationRepository, NotificationRepository>();
            services.AddScoped<INotificationService, NotificationService>();

            // Event Bus — singleton so subscription list survives the whole app
            services.AddSingleton<IEventBus, InMemoryEventBus>();

            // Handlers — transient, stateless, one per event fire
            services.AddTransient<IncidentCreatedHandler>();
            services.AddTransient<IncidentResolvedHandler>();
            services.AddTransient<ComplianceRecordedHandler>();
            services.AddTransient<ComplianceDueHandler>();
            services.AddTransient<RouteDelayedHandler>();
            services.AddTransient<ScheduleChangedHandler>();

            return services;
        }

        // called AFTER app.Build() — DI container is ready here
        public static WebApplication UseNotificationModule(
            this WebApplication app)
        {
            var bus = app.Services.GetRequiredService<IEventBus>();

            bus.Subscribe<IncidentCreatedEvent, IncidentCreatedHandler>();
            bus.Subscribe<IncidentResolvedEvent, IncidentResolvedHandler>();
            bus.Subscribe<ComplianceRecordedEvent, ComplianceRecordedHandler>();
            bus.Subscribe<ComplianceDueEvent, ComplianceDueHandler>();
            bus.Subscribe<RouteDelayedEvent, RouteDelayedHandler>();
            bus.Subscribe<ScheduleChangedEvent, ScheduleChangedHandler>();

            return app;
        }
    }
}

// NotificationId, UserId, EntityId, Message, Category, Status, CreatedDate
using TranspoLink.SharedKernel.Entities;
using TranspoLink.SharedKernel.Enums;

namespace TranspoLink.Modules.Notification.Domain.Entities;


    public class NotificationAlert : BaseEntity
    {
        public Guid NotificationID { get; set; }
        public Guid UserID { get; set; }
        public Guid EntityID { get; set; }
        public string Message { get; set; } = string.Empty;

        // Using the shared enum
        public StatusType Status { get; set; } = StatusType.Unread;

        public DateTime CreatedDate { get; set; } = DateTime.UtcNow;

        // If Category is still needed, use string (not enum), because shared enum does not contain categories
        public string Category { get; set; } = string.Empty;
    }


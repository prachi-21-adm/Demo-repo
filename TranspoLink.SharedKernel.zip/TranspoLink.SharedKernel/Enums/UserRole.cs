namespace TranspoLink.SharedKernel.Enums;

/// <summary>
/// Defines every actor role in TranspoLink.
/// Stored as a string in the database via .HasConversion<string>() in UserConfiguration.
/// Used for JWT claims, role-based access checks, and ICurrentUserService.Role comparisons.
/// </summary>
public enum UserRole
{
    Citizen,            // Can report incidents, view transport schedules
    TrafficOfficer,     // Can resolve incidents, update road segment status
    TransportOperator,  // Can manage routes, schedules, and fleets
    Admin,              // Full access to all modules
    Compliance          // Can create audits and compliance records
}

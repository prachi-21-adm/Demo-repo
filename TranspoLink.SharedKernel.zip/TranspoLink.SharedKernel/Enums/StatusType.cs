namespace TranspoLink.SharedKernel.Enums;

/// <summary>
/// General-purpose status enum used across multiple modules.
/// Individual modules use string comparisons in their services (e.g. "Open", "Resolved")
/// because the seeded data uses string values in the DB — this enum is for typed C# logic.
/// 
/// Incident statuses:   Open | Resolved | Pending
/// Segment statuses:    Active | Congested | Inactive
/// Schedule statuses:   OnTime | Delayed | Cancelled
/// Fleet statuses:      Available | InService | UnderMaintenance
/// Route statuses:      Active | Inactive
/// Audit statuses:      Open | Closed
/// Compliance results:  Pass | Fail
/// Notification status: Unread | Read
/// </summary>
public enum StatusType
{
    // General
    Active,
    Inactive,
    Pending,

    // Incident lifecycle
    Open,
    Resolved,
    Cancelled,

    // Schedules
    OnTime,
    Delayed,

    // Fleets
    Available,
    InService,
    UnderMaintenance,

    // Audits
    Closed,

    // Compliance results
    Pass,
    Fail,

    // Notifications
    Unread,
    Read,

    // Road segments
    Congested
}

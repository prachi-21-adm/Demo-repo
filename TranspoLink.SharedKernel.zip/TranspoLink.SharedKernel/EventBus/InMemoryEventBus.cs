﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace TranspoLink.SharedKernel.EventBus;

public class InMemoryEventBus : IEventBus
{
    private readonly IServiceProvider _sp;
    private readonly ILogger<InMemoryEventBus> _logger;

    // event type → list of handler types
    private static readonly Dictionary<Type, List<Type>> _subs = new();

    public InMemoryEventBus(IServiceProvider sp, ILogger<InMemoryEventBus> logger)
    {
        _sp = sp;
        _logger = logger;
    }

    public void Subscribe<TEvent, THandler>()
        where TEvent : IEvent
        where THandler : IEventHandler<TEvent>
    {
        var key = typeof(TEvent);
        if (!_subs.ContainsKey(key))
            _subs[key] = new List<Type>();

        if (!_subs[key].Contains(typeof(THandler)))
            _subs[key].Add(typeof(THandler));
    }

    public async Task PublishAsync<TEvent>(TEvent evt, CancellationToken ct = default)
        where TEvent : IEvent
    {
        var key = typeof(TEvent);
        if (!_subs.TryGetValue(key, out var handlerTypes)) return;

        using var scope = _sp.CreateScope();

        foreach (var handlerType in handlerTypes)
        {
            try
            {
                var handler = scope.ServiceProvider.GetRequiredService(handlerType);
                // cast to the typed interface and invoke
                var typedHandler = (IEventHandler<TEvent>)handler;
                await typedHandler.HandleAsync(evt, ct);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex,
                    "Handler {Handler} failed for event {Event}",
                    handlerType.Name, key.Name);
                // swallow so other handlers still run
            }
        }
    }
}

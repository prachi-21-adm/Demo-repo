﻿
namespace TranspoLink.SharedKernel.EventBus;

public interface IEvent
{
    Guid EventId { get; }
    DateTime OccurredOn { get; }
}

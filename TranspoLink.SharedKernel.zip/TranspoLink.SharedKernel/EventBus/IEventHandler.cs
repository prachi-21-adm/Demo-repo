﻿namespace TranspoLink.SharedKernel.EventBus;

public interface IEventHandler<TEvent> where TEvent : IEvent
{
    Task HandleAsync(TEvent evt, CancellationToken ct = default);
}

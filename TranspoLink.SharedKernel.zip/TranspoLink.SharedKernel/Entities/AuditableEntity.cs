using TranspoLink.SharedKernel.Entities;

namespace TranspoLink.SharedKernel.Entities;

/// <summary>
/// Extends BaseEntity with CreatedBy / ModifiedBy audit columns.
/// Use for entities that need a full audit trail (who created, who last changed).
/// Example users: ComplianceRecord, Audit
/// </summary>
public abstract class AuditableEntity : BaseEntity
{
    // The UserID (as string) of whoever created this record
    public string? CreatedBy { get; set; }

    // The UserID (as string) of whoever last modified this record
    public string? ModifiedBy { get; set; }
}

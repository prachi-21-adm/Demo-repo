namespace TranspoLink.SharedKernel.Entities;
///
/// Without this: you'd add CreatedAt/UpdatedAt to 15+ entity classes manually.
/// With this: every entity gets them for free by writing ": BaseEntity".
///
/// All module entities extend this:
///   User, AuditLog, Incident, Resolution, RoadSegment, TrafficFlow,
///   TransportRoute, Schedule, Fleet, ComplianceRecord, Audit, Notification, Report
/// </summary>
public abstract class BaseEntity
{
    // Changed to int to match your IRepository and ICurrentUserService
    public Guid Id { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
}

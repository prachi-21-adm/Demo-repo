namespace TranspoLink.SharedKernel.Constants;

/// <summary>
/// Application-wide constants used across all modules.
/// Define magic numbers and strings ONCE here — never hardcode them in multiple places.
/// </summary>
public static class AppConstants
{
    // ── Pagination ────────────────────────────────────────────────────────────
    public const int DefaultPageSize = 10;
    public const int MaxPageSize = 50;

    // ── JWT Claims ────────────────────────────────────────────────────────────
    // These are the claim key names written into the JWT token on login
    // and read back by ICurrentUserService from the HttpContext
    public const string JwtClaimUserId = "userId";
    public const string JwtClaimRole = "role";
    public const string JwtClaimEmail = "email";
    public const string JwtClaimName = "name";

    // ── Authorization Policy Names ────────────────────────────────────────────
    // Used in [Authorize(Policy = AppConstants.PolicyAdmin)] on controllers
    public const string PolicyAdmin = "AdminOnly";
    public const string PolicyOfficerOrAbove = "OfficerOrAbove";
    public const string PolicyCompliance = "ComplianceOnly";
    public const string PolicyOperator = "OperatorOrAbove";

    // ── Date Formats ──────────────────────────────────────────────────────────
    // Used in mapping profiles for consistent date formatting across all DTOs
    public const string DateDisplayFormat = "dd MMM yyyy";
    public const string DateTimeDisplayFormat = "dd MMM yyyy HH:mm";

    // ── Report Constraints ────────────────────────────────────────────────────
    public const int MaxReportDateRangeDays = 365;

    // ── Status String Values ──────────────────────────────────────────────────
    // These match exactly what the seeded TranspoLinkDB contains
    // Used in LINQ string comparisons in all services
    public static class Status
    {
        // Incidents
        public const string Open = "Open";
        public const string Resolved = "Resolved";
        public const string Pending = "Pending";

        // Routes / Segments / Users / Fleets
        public const string Active = "Active";
        public const string Inactive = "Inactive";

        // Segments
        public const string Congested = "Congested";

        // Schedules
        public const string OnTime = "OnTime";
        public const string Delayed = "Delayed";
        public const string Cancelled = "Cancelled";

        // Fleets
        public const string Available = "Available";
        public const string InService = "InService";
        public const string UnderMaintenance = "UnderMaintenance";

        // Audits
        public const string Closed = "Closed";

        // Compliance
        public const string Pass = "Pass";
        public const string Fail = "Fail";

        // Notifications
        public const string Unread = "Unread";
        public const string Read = "Read";
    }

    // ── Incident Type String Values ───────────────────────────────────────────
    public static class IncidentType
    {
        public const string Accident = "Accident";
        public const string Breakdown = "Breakdown";
        public const string Roadblock = "Roadblock";
    }

    // ── Route Type String Values ──────────────────────────────────────────────
    public static class RouteType
    {
        public const string Bus = "Bus";
        public const string Train = "Train";
    }

    // ── Notification Category String Values ───────────────────────────────────
    public static class NotificationCategory
    {
        public const string Incident = "Incident";
        public const string Transport = "Transport";
        public const string Compliance = "Compliance";
    }

    // ── Compliance Type String Values ─────────────────────────────────────────
    public static class ComplianceType
    {
        public const string Incident = "Incident";
        public const string Transport = "Transport";
    }
}

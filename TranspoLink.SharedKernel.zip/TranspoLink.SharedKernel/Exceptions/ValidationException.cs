namespace TranspoLink.SharedKernel.Exceptions;

/// <summary>
/// Thrown when request input fails business validation rules.
/// Caught by ExceptionHandlingMiddleware → returns HTTP 422 Unprocessable Entity.
///
/// Thrown by validator classes BEFORE any database call is made.
/// The message can contain multiple errors joined with " | ".
///
/// Usage — single error:
///   throw new ValidationExceptions("FromDate must be earlier than ToDate.");
///
/// Usage — multiple errors (from validator):
///   var errors = new List&lt;string&gt;();
///   if (dto.FromDate >= dto.ToDate)
///       errors.Add("FromDate must be earlier than ToDate.");
///   if ((dto.ToDate - dto.FromDate).TotalDays > 365)
///       errors.Add("Date range cannot exceed 365 days.");
///   if (errors.Any())
///       throw new ValidationExceptions(string.Join(" | ", errors));
/// </summary>
public class ValidationExceptions : Exception
{
    public ValidationExceptions(string message) : base(message) { }
}

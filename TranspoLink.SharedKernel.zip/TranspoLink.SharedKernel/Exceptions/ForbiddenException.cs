namespace TranspoLink.SharedKernel.Exceptions;

/// <summary>
/// Thrown when the authenticated user does not have permission to perform an action.
/// Caught by ExceptionHandlingMiddleware → returns HTTP 403 Forbidden.
///
/// Note the difference:
///   401 Unauthorized = user is NOT logged in (no token / invalid token)
///   403 Forbidden    = user IS logged in but their ROLE doesn't allow this action
///
/// Usage:
///   if (_currentUser.Role != "Admin")
///       throw new ForbiddenException("Only administrators can delete reports.");
///
///   if (_currentUser.Role != "TrafficOfficer" && _currentUser.Role != "Admin")
///       throw new ForbiddenException("Only Traffic Officers can resolve incidents.");
/// </summary>
public class ForbiddenException : Exception
{
    public ForbiddenException(string message) : base(message) { }
}

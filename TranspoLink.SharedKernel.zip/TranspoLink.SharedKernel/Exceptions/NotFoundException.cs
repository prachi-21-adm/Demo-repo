namespace TranspoLink.SharedKernel.Exceptions;

/// <summary>
/// Thrown when a requested resource cannot be found in the database.
/// Caught by ExceptionHandlingMiddleware → returns HTTP 404 Not Found.
///
/// Usage:
///   var report = await _db.Reports.FindAsync(id)
///       ?? throw new NotFoundException($"Report with ID {id} not found.");
///
///   var user = await _db.Users.FirstOrDefaultAsync(u => u.Email == email)
///       ?? throw new NotFoundException($"No user found with email {email}.");
/// </summary>
public class NotFoundException : Exception
{
    public NotFoundException(string message) : base(message) { }
}

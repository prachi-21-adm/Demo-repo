namespace TranspoLink.SharedKernel.Response;

/// <summary>
/// Standard pagination wrapper for any list endpoint that could return many rows.
/// Used as the Data payload inside ApiResponse when returning paginated lists.
///
/// Full response shape — GET /api/reporting/scope/Incident?page=2&pageSize=10:
/// {
///   "success": true,
///   "data": {
///     "items": [ {...}, {...}, {...} ],
///     "totalCount": 47,
///     "page": 2,
///     "pageSize": 10,
///     "totalPages": 5,
///     "hasNext": true,
///     "hasPrevious": true
///   },
///   "message": "Incident reports fetched successfully."
/// }
///
/// Usage in a service:
///   var total = await query.CountAsync();
///   var items = await query.Skip((page-1) * pageSize).Take(pageSize).ToListAsync();
///   return new PagedResult&lt;ReportDto&gt;
///   {
///       Items      = items.Select(MapToDto).ToList(),
///       TotalCount = total,
///       Page       = page,
///       PageSize   = pageSize
///   };
/// </summary>
public class PagedResult<T>
{
    // The records for the current page
    public List<T> Items { get; set; } = [];

    // Total number of matching records in the database (across ALL pages)
    public int TotalCount { get; set; }

    // The current page number (1-based, not 0-based)
    public int Page { get; set; }

    // How many records per page was requested
    public int PageSize { get; set; }

    // Calculated: how many pages exist in total
    // e.g. TotalCount=47, PageSize=10 → TotalPages=5 (ceil(47/10))
    public int TotalPages => (int)Math.Ceiling((double)TotalCount / PageSize);

    // True if there is at least one more page after this one
    // Frontend uses this to show/hide "Next" button
    public bool HasNext => Page < TotalPages;

    // True if this is not the first page
    // Frontend uses this to show/hide "Previous" button
    public bool HasPrevious => Page > 1;
}

namespace TranspoLink.SharedKernel.Response;

/// <summary>
/// Standard response envelope returned by every controller in every module.
/// Wraps all API responses in a consistent shape so the frontend always knows
/// exactly what to expect, regardless of which endpoint it calls.
///
/// On SUCCESS — GET /api/reporting/dashboard:
/// {
///   "success": true,
///   "data": { "totalIncidents": 8, "openIncidents": 3, ... },
///   "message": "Dashboard loaded successfully.",
///   "errors": []
/// }
///
/// On FAILURE — validation error (422):
/// {
///   "success": false,
///   "data": null,
///   "message": "Validation failed.",
///   "errors": ["FromDate must be earlier than ToDate.", "Date range cannot exceed 365 days."]
/// }
///
/// Usage in a controller:
///   return Ok(new ApiResponse&lt;DashboardDto&gt;
///   {
///       Success = true,
///       Data    = dashboard,
///       Message = "Dashboard loaded successfully."
///   });
/// </summary>
public class ApiResponse<T>
{
    // True if the request completed without errors, false otherwise
    public bool Success { get; set; }

    // The actual response payload — null on errors
    // T can be: DashboardDto, ReportDto, PagedResult<ReportDto>, string, etc.
    public T? Data { get; set; }

    // Human-readable summary: "Report generated successfully." or "Validation failed."
    public string Message { get; set; } = string.Empty;

    // List of error messages — empty on success, populated on validation/not-found errors
    // The ExceptionHandlingMiddleware populates this from exception messages
    public List<string> Errors { get; set; } = [];

    // ── Convenience factory methods ────────────────────────────────────────────

    /// <summary>Creates a successful response with data and message.</summary>
    public static ApiResponse<T> Ok(T data, string message = "Success") => new()
    {
        Success = true,
        Data = data,
        Message = message
    };

    /// <summary>Creates a failed response with error messages.</summary>
    public static ApiResponse<T> Fail(string message, List<string>? errors = null) => new()
    {
        Success = false,
        Message = message,
        Errors = errors ?? []
    };
}

namespace TranspoLink.SharedKernel.Interfaces;

/// <summary>
/// Provides the currently logged-in user's identity from anywhere in the application.
///
/// The concrete implementation reads the JWT claims from IHttpContextAccessor.
/// Registered as AddScoped in each module's extension — one instance per HTTP request.
///
/// How it works:
///   1. User logs in via POST /api/identity/login
///   2. IdentityService generates a JWT containing userId and role claims
///   3. Client sends "Authorization: Bearer {token}" on every subsequent request
///   4. ASP.NET validates the JWT and populates HttpContext.User.Claims
///   5. ICurrentUserService reads those claims — available in any service
///
/// Usage in a service:
///   if (_currentUser.Role != "Admin")
///       throw new ForbiddenException("Admins only.");
///   var createdBy = _currentUser.UserId.ToString();
/// </summary>
public interface ICurrentUserService
{
    // The primary key of the logged-in user (from the userId JWT claim)
    Guid UserId { get; }

    // The role of the logged-in user as a string: "Admin", "TrafficOfficer", etc.
    // Matches UserRole enum values exactly
    string Role { get; }

    // The email of the logged-in user (from the email JWT claim)
    string Email { get; }

    // The display name of the logged-in user (from the name JWT claim)
    string Name { get; }

    // True if the request carries a valid JWT and the user is authenticated
    bool IsAuthenticated { get; }

    string IpAddress { get; }
}

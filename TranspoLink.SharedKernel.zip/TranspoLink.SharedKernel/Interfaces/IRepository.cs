using TranspoLink.SharedKernel.Entities;

namespace TranspoLink.SharedKernel.Interfaces;

public interface IRepository<T> where T : BaseEntity
{
    Task<T?> GetByIdAsync(int id);
    Task<IEnumerable<T>> GetAllAsync();
    Task AddAsync(T entity);
    Task UpdateAsync(T entity);
    Task DeleteAsync(int id);
    // Added SaveChanges to the interface so the Unit of Work pattern stays in the Repo
    Task<int> SaveChangesAsync();
}
